package com.niit.shoopingcart.dao.impl;





import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

@Repository("UserDAO")
public class UserDAOimp implements UserDAO {
	@Autowired
	SessionFactory sessionFactory;
	public UserDAOimp(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
   @Transactional
	public boolean save(User user) {
	   try {
		sessionFactory.getCurrentSession().save(user);
		return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	
		// TODO Auto-generated method stub
		return false;
	}}
   @Transactional
	public boolean update(User user) {
	   try {
		sessionFactory.getCurrentSession().update(user);
		return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	
		// TODO Auto-generated method stub
		return false;
	}}
    @Transactional
	public boolean delete(User user) {
    	try {
			sessionFactory.getCurrentSession().delete(user);
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		// TODO Auto-generated method stub
		return false;
	}}
    @Transactional
	public User get(String id) {
    	{
    		String hql="from User where id='"+id+"'";
    		 List<User> li=sessionFactory.getCurrentSession().createQuery(hql).list();
    		 if(li==null||li.isEmpty())
    			 return null;
    		 else
    			 return li.get(0);
    	
		// TODO Auto-generated method stub
    	}
	
		// TODO Auto-generated method stub
	
	}
    @Transactional
	public List<User> list() {
    	 String hql ="from User";
		   List<User> li=sessionFactory.getCurrentSession().createQuery(hql).list();
			// TODO Auto-generated method stub
			return li;
	   	
	
		// TODO Auto-generated method stub
	
	}

}