package com.niit.shoopingcart.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.dao.ProductDAO;

import com.niit.shoppingcart.model.Product;

@Repository("productDAO")
	public class ProductDAOimp implements ProductDAO {
	@Autowired
	private SessionFactory sessionFactory;
	public ProductDAOimp(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
			}


	@Transactional
	public boolean save(Product category) {
		try {
			sessionFactory.getCurrentSession().save(category);
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		// TODO Auto-generated method stub
		return false;
	}

	@Transactional
	public boolean update(Product category) {
		try {
			sessionFactory.getCurrentSession().update(category);
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		// TODO Auto-generated method stub
		return false;
	}

	@Transactional
	public Product get(String id) {
	
			String hql="from category where id='"+id+"'";
			List<Product> li=sessionFactory.getCurrentSession().createQuery(hql).list();
		if (li==null||li.isEmpty())
			return null;
			else
			return li.get(0);
	}

	@Transactional
	public boolean delete(Product category) {
		try {
			sessionFactory.getCurrentSession().delete(category);
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		// TODO Auto-generated method stub
		return false;
	}

	@Transactional
	public List<Product> list() {
		String hql="from Category";
		List<Product> li=sessionFactory.getCurrentSession().createQuery(hql).list();
		return li;
	}
}

