package com.niit.shoopingcart.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.model.Supplier;
@Repository("SupplierDAO")
public class SupplierDAOimp implements SupplierDAO{


		@Autowired
		Supplier supplier;
		
		@Autowired
		SessionFactory sessionFactory;
		
		public SupplierDAOimp(SessionFactory sessionFactory)
		{
			this.sessionFactory=sessionFactory;
		}

	
@Transactional
	public boolean save(Supplier supplier) {
		try {
			sessionFactory.getCurrentSession().save(supplier);
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		return false;
	}
	}
@Transactional
	public boolean update(Supplier supplier) {
		// TODO Auto-generated method stub
		try {
			sessionFactory.getCurrentSession().update(supplier);
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		return false;
	}
	}
@Transactional
	public boolean delete(Supplier supplier) {
		// TODO Auto-generated method stub
		try {
			sessionFactory.getCurrentSession().delete(supplier);
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		return false;
	}
	}
@Transactional
	public Supplier get(String id) {
		
			
			String hql="from Supplier where id='"+id+"'";
			List<Supplier> sli=sessionFactory.getCurrentSession().createQuery(hql).list();
			if(sli==null||sli.isEmpty())
				return null;
			else
				return sli.get(0);
			}
		
		
	
@Transactional
	public List<Supplier> list() {
		String hql="from Supplier";
		List<Supplier> sli=sessionFactory.getCurrentSession().createQuery(hql).list();
		return sli;
	}

}