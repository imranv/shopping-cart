package com.niit.shoppingcart.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Product;
@Repository("productDAO")
public interface ProductDAO 
{

public boolean save(Product product);
public boolean update(Product category);
public Product get(String id);
public boolean delete(Product category);
public List<Product> list();
}
