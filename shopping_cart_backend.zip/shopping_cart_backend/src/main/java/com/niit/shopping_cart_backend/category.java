package com.niit.shopping_cart_backend;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;


@Entity
@Table(name="category")
@Component

//if the table name is same as class name

public class Category {
	
//id,name,description
	//these property names better to take same name as fields names
	//in the category table
	
	
	@Id
	private String id;
	//@column(name="name") //optional if the property name in this the class
	//same as field name in the table
	 
	private String name;
	
	//@column (name="description")//optional
	private String description;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
}
