package com.niit.shopping_cart_backend;



import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.model.Supplier;


public class suppliertestcase {
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		SupplierDAO supplierDAO = (SupplierDAO) context.getBean("SupplierDAO");
		Supplier supplier=(Supplier) context.getBean("supplier");
   supplier.setId("sup_03");
   supplier.setName("rishabh");
   supplier.setAddress("hyderabad");
   
   supplier.setId("sup_0");
   supplier.setName("Bhaveena");
   supplier.setAddress("Nellore");
   
   //supplier.setId("sup_01");
   //supplier.setName("Spuu");
   //supplier.setAddress("Anantapur");
   
   
   
  // System.out.println(supplierDAO.save(supplier));
 System.out.println("data inserted into db....");
 //supplier.setId("sup_0");
	//supplierDAO.update(supplier);
			
	//System.out.println("data updated..........");
 //supplier.setId("sup_03");
	//supplierDAO.delete(supplier);

   
	//System.out.println("data deleted in db....");
	List<Supplier> slist=supplierDAO.list();
		for(Supplier s:slist)
		{
			System.out.println("product name:"+s.getName());
			//System.out.println("product ID:"+s.getId());
		//	System.out.println("product price:"+s.getAddress());
			
		}
} 
}
