package com.niit.shopping_cart_backend;



import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.ProductDAO;

import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Product;



public class producttestcase {


	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
		Product product = (Product) context.getBean("product");
		
		

		 product.setId("MOB003");
		product.setName("MOBILE");
		 product.setDescription("iphone 6s");
		 
		 product.setId("MOB00");
			product.setName("furniture");
			 product.setDescription("table");
			 

			 product.setId("MOB005");
				product.setName("kitchen");
				 product.setDescription("GAS STOVE");

				 product.setId("MOB007");
					product.setName("LAPTOP");
					 product.setDescription("LENOVO");


		
		System.out.println(productDAO.save(product));
			// product.setId("MOB00");
		//productDAO.delete(product);
		//productDAO.update(product);
		List<Product> clist=productDAO.list();
		//for (Product c:clist)
		//{
		//System.out.println("category name:"+c.getName());
	}
		
			
			
			
}

