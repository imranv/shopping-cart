package com.niit.shopping_cart_backend;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.model.Category;
public class categorytestcase {

public static void main(String[] args) {
	

	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
	context.scan("com.niit.shoppingcart");
	context.refresh();
	CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
	Category category = (Category) context.getBean("category");
	 

	// category.setId("MOB003");
	// category.setName("MOBILE");
	 //category.setDescription("iphone 6s");
	 
//	 category.setId("MOB004");
//	 category.setName("T.V");
//	 category.setDescription("SONY BRAVIA");
//	 
//	 category.setId("MOB005");
//	category.setName("LAPTOP");
//	 category.setDescription("LENOVO");
//	 
//	 category.setId("MOB006");
//	 category.setName("COMPUTER");
//	 category.setDescription("DELL");
	 
	System.out.println(categoryDAO.save(category));
	// categoryDAO.delete(category);
	 //categoryDAO.update(category);
	System.out.println("Data inserted into DB");
	List<Category> clist=categoryDAO.list();
	for (Category c:clist)
	{
		System.out.println("category name:"+c.getName());
	}
	
	
	

}
}