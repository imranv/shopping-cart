//package com.niit.shopping_cart_backend;
//
//import org.junit.Before;
//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.AnnotationConfigApplicationContext;
//import org.springframework.util.Assert;
//
//import com.niit.shoppingcart.dao.CategoryDAO;
//import com.niit.shoppingcart.model.Category;
//
//
//public class categorytestcase1 {
//
//
// @Autowired
// AnnotationConfigApplicationContext context;
// 
// @Autowired
// Category category;
// 
// @Autowired
// CategoryDAO categoryDAO;
// 
// @Before
// public void init()
// {
//	 context = new  AnnotationConfigApplicationContext();
//	 context.scan("com.niit");
//	 context.refresh();
//	 CategoryDAO categoryDAO=(CategoryDAO) context.getBean("categoryDAO");
//	 Category category=(Category) context.getBean("category");
// 
//	category.setId("KIB_24");
//	category.setDescription("this is electronics category");
//	category.setName("mobiles");
//    System.out.println(categoryDAO.save(category);
//
//}
//}