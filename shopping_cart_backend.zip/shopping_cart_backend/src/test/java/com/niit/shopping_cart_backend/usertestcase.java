package com.niit.shopping_cart_backend;


import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;


public class usertestcase {
public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		UserDAO userDAO = (UserDAO) context.getBean("UserDAO");
		User user = (User) context.getBean("user");

		user.setId("US01");
		 user.setName("AYAN");
		 user.setPassword("BANGARAM");
		 user.setContact("8877143143");
		 user.setEmail("AYANKEERTHI@gmail.com");
		 user.setRole("ADMIN");
//		 
//		 user.setId("US02");
//		user.setName("IMMU");
//		 user.setPassword("BEAULA");
//		 user.setContact("9988143143");
//		user.setEmail("IMMUBEAULA@gmail.com");
//		 user.setRole("CUSTOMER");

			 
	//System.out.println(userDAO.save(user));
		// user.setId("US01"); 
	//userDAO.delete(user);
	//userDAO.update(user);
		//System.out.println("Data deleted in DB");
       //System.out.println("data inserted in db");
	//System.out.println("data updated");
	List<User> clist=userDAO.list();
	for(User c:clist)
	{
		System.out.println("User name:"+c.getName());
		System.out.println("User id:"+c.getId());
	}
}
	}
	
		
		
			
	
