package com.niit.shopping_cart_backend;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.CartDAO;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Supplier;

public class carttestcase {
public static void main(String[] args) {
		 
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		CartDAO cartDAO =(CartDAO)context.getBean("cartDAO");
		Cart cart=(Cart) context.getBean("cart");
		
		
	cart.setId("CA001"); 
       cart.setOrder_id("OR001");
        cart.setBilling_address_id("002");
        cart.setShipping_address_id("0002");
        cart.setPayment_method("DEBIT CARD");
        
//        
//    	cart.setId("CA002"); 
//        cart.setOrder_id("OR002");
//        cart.setBilling_address_id("001");
//        cart.setShipping_address_id("0003");
//        cart.setPayment_method("C.O.D");

        
      //System.out.println(cartDAO.save(cart));
      // System.out.println("data inserted into db....");
       //
     //	cartDAO.update(cart);
      			
      	//System.out.println("data updated..........");
      	//cart.setId("CA001");
     //cartDAO.delete(cart);

         
      	//System.out.println("data deleted in db....");
      	List<Cart> clist=cartDAO.list();
      		for(Cart c:clist)
      		{

      			//System.out.println("User name:"+c.getName());
      			System.out.println("User id:"+c.getOrder_id());
      		

}
} 
}


