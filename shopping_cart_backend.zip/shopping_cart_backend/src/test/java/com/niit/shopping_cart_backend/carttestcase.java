package com.niit.shopping_cart_backend;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.CartDAO;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Supplier;

public class carttestcase {
public static void main(String[] args) {
		 
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		CartDAO cartDAO =(CartDAO)context.getBean("cartDAO");
		Cart cart=(Cart) context.getBean("cart");
		
		cart.setId("CA001"); 
        cart.setOrder_id("OR001");
        cart.setBilling_address_id("002");
        cart.setShipping_address_id("0002");
        cart.setPayment_method("DEBIT CARD");

        
        System.out.println(cartDAO.save(cart));
       System.out.println("data inserted into db....");
       //supplier.setId("sup_0");
      	//supplierDAO.update(supplier);
      			
      	//System.out.println("data updated..........");
       //supplier.setId("sup_03");
      	//supplierDAO.delete(supplier);

         
      	//System.out.println("data deleted in db....");
      	//List<Supplier> slist=supplierDAO.list();
      		//for(Supplier s:slist)
      		{

}
} 



}